
import React, { useEffect, useState } from "react";
import { initializeApp } from "firebase/app";
import { getFirestore, collection, addDoc, getDocs } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_AUTH_DOMAIN",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_STORAGE_BUCKET",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID",
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export default function App() {
  const [articles, setArticles] = useState([]);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");

  useEffect(() => {
    fetchArticles();
  }, []);

  const fetchArticles = async () => {
    const querySnapshot = await getDocs(collection(db, "articles"));
    const data = querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    setArticles(data);
  };

  const addArticle = async () => {
    if (!title || !content) return;
    await addDoc(collection(db, "articles"), { title, content });
    setTitle("");
    setContent("");
    fetchArticles();
  };

  return (
    <div style={{ padding: "40px", fontFamily: "Arial" }}>
      <h1>🚀 Rapid Tech Innovation</h1>
      <h2>AI & Tech Blog</h2>

      <input
        placeholder="Article Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        style={{ display: "block", marginBottom: "10px", padding: "8px", width: "300px" }}
      />

      <textarea
        placeholder="Write your article..."
        value={content}
        onChange={(e) => setContent(e.target.value)}
        style={{ display: "block", marginBottom: "10px", padding: "8px", width: "300px", height: "100px" }}
      />

      <button onClick={addArticle} style={{ padding: "8px 16px" }}>
        Publish Article
      </button>

      <hr style={{ margin: "30px 0" }} />

      {articles.map((article) => (
        <div key={article.id} style={{ marginBottom: "20px" }}>
          <h3>{article.title}</h3>
          <p>{article.content}</p>
        </div>
      ))}

      <hr />
      <h3>💰 Monetization Options</h3>
      <ul>
        <li>Google AdSense</li>
        <li>Affiliate Marketing</li>
        <li>Sponsored Posts</li>
      </ul>
    </div>
  );
}
